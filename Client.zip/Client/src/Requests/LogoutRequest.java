package Requests;

import PaquetesModels.Paquete;

/**
 * Solicitud de Logout
 * 
 * El cliente lo solicita cuando requiere cerrar sesión
 * 
 * @author Juan Robles
 */
public class LogoutRequest extends Paquete {

    // Orden que identifica al tipo de paquete
    public static final String ORDEN = "request-logout";

    public LogoutRequest() {
        super(ORDEN);
    }

}
