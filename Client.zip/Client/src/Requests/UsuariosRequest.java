package Requests;

import PaquetesModels.Paquete;

/**
 * Solicitud de Usuarios
 * 
 * El cliente lo envía cuando desea actualizar su lista de usuarios y amigos
 * 
 * @author Juan Robles
 */
public class UsuariosRequest extends Paquete {

    // Orden que identifica al tipo de paquete
    public static final String ORDEN = "request-usuarios";

    public UsuariosRequest() {
        super(ORDEN);
    }

}
