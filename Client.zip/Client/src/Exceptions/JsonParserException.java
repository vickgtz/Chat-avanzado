package Exceptions;

/**
 * Excepción para las conversiones JSON
 * @author Mariana Ramírez
 */
public class JsonParserException extends Exception {
    
    /**
     * Constructor encargado de mandar recuperar  mensaje de error
     * @param message mensaje de error 
     */

    public JsonParserException(String message) {
        super(message);
    }

}
