package Exceptions;

/**
 * Excepción en el manejo de paquetes
 * @author Mariana Ramírez
 */
public class PaqueteException extends Exception {

    /**
     * constructor encargado de obtener el mensaje de error
     * @param message mesaje de error 
     */
    public PaqueteException(String message) {
        super(message);
    }

}
