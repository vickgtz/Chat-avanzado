package Exceptions;

/**
 * Excepción para las operaciones de HiloReceiver
 * @author Mariana Ramírez
 */
public class InvalidOperationException extends Exception {
    
    /**
     * Constructor encargado de recuperar el menaje de error 
     * @param message mensaje de error
     */

    public InvalidOperationException(String message) {
        super(message);
    }

}
