package ModelsSerializables;

import java.io.Serializable;

/**
 *
 * @author Jonathan Vázquez
 */
public class UsuarioSerializable implements Serializable {

    public String username;
    public String nombre;
    public boolean connected;

    public UsuarioSerializable() {
    }

    /**
     * Constructor 
     * @param username
     * @param nombre
     * @param connected 
     */
    public UsuarioSerializable(String username, String nombre, boolean connected) {
        this.username = username;
        this.nombre = nombre;
        this.connected = connected;
    }
}
