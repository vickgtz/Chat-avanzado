package chat.exceptions;

/**
 * Excepción para las conversiones JSON
 * @author Vicktor
 */
public class JsonParserException extends Exception {

    public JsonParserException(String message) {
        super(message);
    }

}
