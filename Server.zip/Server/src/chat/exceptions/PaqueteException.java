package chat.exceptions;

/**
 * Excepción en el manejo de paquetes
 * @author Vicktor
 */
public class PaqueteException extends Exception {

    public PaqueteException(String message) {
        super(message);
    }

}
