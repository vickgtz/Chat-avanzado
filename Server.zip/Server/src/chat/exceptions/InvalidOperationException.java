package chat.exceptions;

/**
 * Excepción para las operaciones de HiloReceiver
 * @author Vicktor
 */
public class InvalidOperationException extends Exception {

    public InvalidOperationException(String message) {
        super(message);
    }

}
