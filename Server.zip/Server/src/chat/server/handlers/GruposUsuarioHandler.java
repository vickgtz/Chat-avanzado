package chat.server.handlers;

import chat.models.UsuarioGrupo;
import chat.paquetes.models.Paquete;
import chat.paquetes.responses.GruposUsuarioResponse;
import chat.server.database.UsuarioGrupoConnector;
import chat.server.vinculo.Vinculo;
import java.util.ArrayList;

/**
 * Handler para grupos - usuarios
 * @author Vicktor
 */
public class GruposUsuarioHandler implements Handler {

    private final Vinculo vinculo;
    
    public GruposUsuarioHandler(Vinculo vinculo){
        this.vinculo = vinculo;
    }

    /**
     * Ejecuta el handler
     * @return El paquete con el resultado
     */    
    @Override
    public Paquete run() {
        ArrayList<UsuarioGrupo> ug = new UsuarioGrupoConnector().getGrupos(vinculo.getUsername());
        
        GruposUsuarioResponse response = new GruposUsuarioResponse();
        
        for(UsuarioGrupo grupo : ug){
              response.addGrupo(grupo.getId_grupo());
        }
        response.finish();
        
        return response;
    }

    
    
}
