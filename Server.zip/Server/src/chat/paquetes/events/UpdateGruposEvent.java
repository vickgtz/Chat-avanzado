package chat.paquetes.events;

import chat.paquetes.models.Paquete;

/**
 * Evento de actualizar Grupos
 * 
 * Se envía al cliente cuando se necesita que se actualicen los grupos
 * 
 * @author Vicktor
 */
public class UpdateGruposEvent extends Paquete {

    // Orden que identifica al tipo de paquete
    public static final String ORDEN = "event-update-grupos";
    
    public UpdateGruposEvent() {
        super(ORDEN);
    }

}
