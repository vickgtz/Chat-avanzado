package chat.paquetes.requests;

import chat.paquetes.models.Paquete;

/**
 *
 * @author Vicktor
 */
public class GruposUsuarioRequest extends Paquete {

    // Orden que identifica al tipo de paquete
    public static final String ORDEN = "request-grupos-usuario";

    public GruposUsuarioRequest() {
        super(ORDEN);
    }

}
